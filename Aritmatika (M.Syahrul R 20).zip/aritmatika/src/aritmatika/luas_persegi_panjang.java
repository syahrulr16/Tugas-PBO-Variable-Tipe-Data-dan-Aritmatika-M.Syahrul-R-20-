package aritmatika;

public class luas_persegi_panjang {
    
    public static void main(String[] args) {
        
    int p = 10;
    int l = 20;
    int t = 30;
    double Luas = p * l * t ;
    
    System.out.println("panjang = " + (p));
    System.out.println("panjang = " + (l));
    System.out.println("panjang = " + (t));
    System.out.println("Luas Persegi panjang = " + (Luas));
    
    }
 
}
